#include "engle.h"
#include <iostream>
#define _USE_MATH_DEFINES
#include <math.h>
#include <cfloat>
using namespace std;

Engle::Engle()
{
    grad = 0; min = 0;
}
Engle::Engle(int g, int m)
{
    grad = g;
    min = m;
    this->Lim();
}
void Engle::Input()
{
    cout<<"enter grad and min ";
    cin>>grad>>min;
    this->Lim();
}
void Engle::Output()
{
    cout<<grad<<"°";
    if (min!=0)
        cout<<min<<"'";
    cout<<endl;
}
double Engle::Rad()
{
    return (grad + min/60.0) * M_PI / 180.0;
}
double Engle::Sin()
{
    return sin(Rad());
}
double Engle::Cos()
{
    return cos(Rad());
}
void Engle::Lim()
{
    while (min >= 60)
    {
        min -= 60.0;
        grad += 1;
    }
    while (min < 0)
    {
        min += 60.0;
        grad -= 1;
    }
    while (grad >= 360 or (grad == 360 and min > 0))
        grad -= 360;
    while (grad < 0)
        grad += 360;
    
}
bool Engle::Equ(Engle z)
{
    if (grad == z.grad && min == z.min)
        return 1;
    return 0;
}
bool Engle::Bigger(Engle z)
{
    if (grad > z.grad)
        return 1;
    if (grad == z.grad and min > z.min )
        return 1;
    return 0;
}
bool Engle::Smaller(Engle z)
{
    if (grad < z.grad)
        return 1;
    if (grad == z.grad and min < z.min)
        return 1;
    return 0;
}
Engle Engle::Plus(double z)
{
    Engle Res;
    int g = int(z);
    double m = (z - g)*60.0;
    Res.grad = grad + g;
    Res.min = min + m;
    Res.Lim();
    return Res;
}
Engle Engle::Minus(double z)
{
    Engle Res;
    int g = int(z);
    double m = (z - g)*60.0;
    Res.grad = grad - g;
    Res.min = min - m;
    Res.Lim();
    return Res;
}
Engle Engle::Prod(double k)
{
    Engle Res;
    Res.grad = grad * k;
    Res.min = min * k;
    Res.Lim();
    return Res;
}
Engle Engle::PlusEngle(Engle z)
{
    Engle Res;
    Res.grad = grad +z.grad;
    Res.min = min+z.min;
    Res.Lim();
    return Res;
}



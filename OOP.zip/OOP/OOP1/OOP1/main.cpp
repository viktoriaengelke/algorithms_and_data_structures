#include "engle.h"
#include <iostream>
#define _USE_MATH_DEFINES
#include <math.h>
using namespace std;

int main()
{
    Engle u;
    u.Output();
    
    u.Input();
    u.Lim();
    u.Output();
    
    cout<<"radians = "<<u.Rad()<<endl;
    
    cout<<"sinus = "<<u.Sin()<<endl;
    cout<<"cosinus = "<<u.Cos()<<endl;
    
    Engle u2;
    u2.Input();
    u2.Output();
    if (u.Equ(u2))
        cout<<"u == u2"<<endl;
    else cout<<"u != u2"<<endl;
    
    Engle u3;
    u3.Input();
    u3.Output();
    if (u.Bigger(u3))
        cout<<"u > u3"<<endl;
    else cout<<"u <= u3"<<endl;
    
    Engle u4;
    u4.Input();
    u4.Output();
    if (u.Smaller(u4))
        cout<<"u < u4"<<endl;
    else cout<<"u >= u4"<<endl;
    
    double z1;
    Engle res1;
    cout<<"vvedi z1: ";
    cin>>z1;
    res1 = u.Plus(z1);
    cout<<"u + z1 = ";
    res1.Output();
    
    double z2;
    Engle res2;
    cout<<"vvedi z2: ";
    cin>>z2;
    res2 = u.Minus(z2);
    cout<<"u - z2 = ";
    res2.Output();
    
    double k;
    Engle res3;
    cout<<"vvedi k: ";
    cin>>k;
    res3 = u.Prod(k);
    cout<<"u * k = ";
    res3.Output();
    
    Engle u5, res4;
    u5.Input();
    u5.Output();
    res4 = u.PlusEngle(u5);
    cout<<"u + u5 = ";
    res4.Output();

}



class Engle
{
private:
    int grad, min;
public:
    Engle();
    Engle(int, int);
    
    void Input();
    void Output();
    double Rad();
    double Sin();
    double Cos();
    
    void Lim();
    
    bool Equ(Engle);
    bool Bigger(Engle);
    bool Smaller(Engle);
    
    Engle Plus(double);
    Engle Minus(double);
    
    Engle Prod(double);
    
    Engle PlusEngle(Engle);

};

#include <iostream>
#include <unistd.h>
#include "BoolMatrix.h"
using namespace std;

int main()
{
//    BoolMatrix B1(4,20);
//    cout<<"B1 = "<<B1<<endl;
    printf("Hello world!\n");

}

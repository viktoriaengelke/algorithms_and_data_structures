//
//  Untitled.swift
//  OOP_Array
//
//  Created by Виктория on 17.09.2025.
//


//
//  main.cpp
//  Polinom-Template
//
//  Created by Виктория on 16.10.2025.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}

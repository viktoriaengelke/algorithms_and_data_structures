#include <iostream>
#include <unistd.h>
#include "BoolMatrix.h"
using namespace std;

int main()
{
    BoolMatrix B1(4,20);
    cout<<"B1 = "<<endl<<B1<<endl;
    
    B1.Invert(0, 10, 8);
    B1.SetUp1(1, 14, 6);
    B1.SetUp1(2, 8, 6);
    for (int j = 1; j < B1.GetCols(); j += 2)
        B1.SetUp1(3, j);
    cout<<"B1 = "<<endl<<B1<<endl;
    
    BoolMatrix B2 = B1;
    cout<<"B2 = "<<endl<<B2<<endl;
    
    if (B1 == B2) cout<<"B1 == B2"<<endl;
    else cout<<"B1 != B2"<<endl;
    
    B2 = B2.ShiftRight(0, 6);
    B2 = B2.ShiftLeft(2, 6);
    B2.SetUp0(1, 16, 1);
    B2.SetUp0(1, 18, 1);
    for (int j = 0; j < B2.GetCols(); j += 2)
        B2.Invert(3, j, 1);
    cout << "new B2 = " << endl << B2 << endl;
    
    BoolMatrix B3;
    cin>>B3;
    cout<<"B3 = "<<endl<<B3<<endl;
    
    char** s = new char*[4];
    char p[50];
    for (int i = 0; i < 4; i++)
    {
        cout<<"enter line number "<<i + 1 << ": ";
        cin>>p;
        s[i] = new char[strlen(p) + 1];
        strcpy(s[i], p);
    }
    cout<<endl;
    BoolMatrix B4(s, 4);
    cout<<"B4 = "<<endl<<B4<<endl;
    
    BoolMatrix C1;
    BoolMatrix C2;
    BoolMatrix C3;
    BoolMatrix C4;
    cout<<"C1 = "<<endl<<C1<<endl;
    if (C1 != B1) cout<<"C1 != B1"<<endl;
    else cout<<"C1 == B1"<<endl;
    
    C1 = B1 & B2;
    C2 = B1 | B2;
    C3 = B1 ^ B2;
    C4 = ~B4;
    cout<<"C1 = "<<endl<<C1<<endl;
    cout<<"C2 = "<<endl<<C2<<endl;
    cout<<"C3 = "<<endl<<C3<<endl;
    cout<<"C4 = "<<endl<<C4<<endl;
    
    B1 &= B2;
    if (C1 != B1) cout<<"C1 != B1"<<endl;
    else cout<<"C1 == B1"<<endl;
    
    cout<<B1[1]<<endl;
    cout<<B1[1][19]<<" "<<B1[1][18]<<endl;
    
    BoolVector A = B1.Disj();
    cout<<"B1.Disj() = "<<A<<endl;
    BoolVector B = B1.Xor();
    cout<<"B1.Xor() = "<<B<<endl;
    cout<<"B1 = "<<endl<<B1<<endl;
}
/*
 
11111111111111111111
00000000000000000000
10101010101010101010
11110000111100001111
 
11111111111111111111
1010101010
1111111111
111100001111

 */
